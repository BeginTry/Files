/*
	https://www.sqlshack.com/how-to-identify-and-monitor-unused-indexes-in-sql-server/
*/
IF EXISTS (
	SELECT *
	FROM tempdb.INFORMATION_SCHEMA.TABLES t
	WHERE t.TABLE_SCHEMA = 'guest'
	AND t.TABLE_NAME = 'UnusedIndexes'
)
BEGIN
	EXEC('DROP TABLE tempdb.guest.UnusedIndexes;');
END

--Create table
SELECT
	--SYSNAME columns.
	DB_NAME() AS DatabaseName, DB_NAME() AS SchemaName, DB_NAME() AS TableName, DB_NAME() AS IndexName,

	--Other columns
    ius.user_seeks, ius.user_scans, ius. user_lookups, ius.user_updates, ius.user_updates AS TableRows,
	CAST('' AS VARCHAR(MAX)) AS DropStatement
INTO tempdb.guest.UnusedIndexes
FROM sys.dm_db_index_usage_stats ius
WHERE 1 = 2;

/******************************************************/
--Run once per database.
DECLARE @TSql NVARCHAR(MAX) = '';
DECLARE @DBName SYSNAME;
DECLARE curDB CURSOR FAST_FORWARD READ_ONLY FOR 
	SELECT name 
	FROM master.sys.databases d
	WHERE d.database_id > 4
	AND d.source_database_id IS NULL	--Exclude snapshots
	AND d.state_desc = 'ONLINE'
	AND d.name NOT IN ('');				--SSRS databases, etc.

OPEN curDB;
FETCH NEXT FROM curDB INTO @DBName;

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @TSql = '
	USE ' + QUOTENAME(@DBName) + ';

INSERT INTO tempdb.guest.UnusedIndexes
SELECT 
	DB_NAME() DatabaseName,
	SCHEMA_NAME(o.schema_id) SchemaName,
    o.name AS Table_name,
    i.name AS Index_name,
    ius.user_seeks,
    ius.user_scans,
    ius. user_lookups,
    ius.user_updates,
	p.TableRows,
	''DROP INDEX ['' + i.name + ''] ON ['' + SCHEMA_NAME(o.schema_id) + ''].['' + 
		OBJECT_NAME(ius.OBJECT_ID) + '']''
FROM sys.dm_db_index_usage_stats ius
JOIN sys.objects o ON ius.OBJECT_ID = o.OBJECT_ID
JOIN sys.indexes i ON i.index_id = ius.index_id AND ius.OBJECT_ID = i.OBJECT_ID
JOIN (SELECT SUM(p.rows) TableRows, p.index_id, p.OBJECT_ID
	FROM sys.partitions p 
	GROUP BY p.index_id, p.OBJECT_ID) p
	ON p.index_id = ius.index_id AND ius.OBJECT_ID = p.OBJECT_ID
WHERE i.index_id <> 0	--Heaps
AND i.is_primary_key = 0 --This line excludes primary key constarint
AND i. is_unique = 0 --This line excludes unique key constarint
AND ius.user_updates <> 0 -- This line excludes indexes SQL Server hasn�t done any work with
AND ius. user_lookups = 0
AND ius.user_seeks = 0
AND ius.user_scans = 0'
	EXEC (@Tsql);

	FETCH NEXT FROM curDB INTO @DBName;
END

CLOSE curDB;
DEALLOCATE curDB;


/*
	SELECT i.sqlserver_start_time
	FROM master.sys.dm_os_sys_info i
*/

SELECT *
FROM tempdb.guest.UnusedIndexes u
WHERE u.IndexName IS NOT NULL
ORDER BY u.DatabaseName, u.SchemaName, u.TableName


