--	Most Costly Queries by Avg CPU usage
;WITH CPUQ AS
(	
	SELECT TOP 30
		[Average CPU] = total_worker_time / qs.execution_count,
		[Total CPU] = total_worker_time,
		[Execution count] = qs.execution_count,
 
		[Individual Query] = REPLACE(
		SUBSTRING(qt.text,
			qs.statement_start_offset / 2,
			(CASE WHEN qs.statement_end_offset = -1
			THEN LEN(CONVERT(NVARCHAR(MAX), qt.text))
			* 2
			ELSE qs.statement_end_offset
			END - qs.statement_start_offset) / 2), '''', ''),

		[Parent Query] = qt.text,
		DatabaseName = DB_NAME(qt.dbid),
		qs.plan_handle
	FROM sys.dm_exec_query_stats qs
	CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS qt
	WHERE qt.dbid != 1
	ORDER BY [Average CPU] DESC
)
SELECT CPUQ.*, qp.query_plan
FROM  CPUQ
CROSS APPLY sys.dm_exec_query_plan(CPUQ.plan_handle) AS qp
