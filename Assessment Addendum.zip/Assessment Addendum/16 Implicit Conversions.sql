/*
	Find execution plans that suffer from implicit conversion.
*/

--By Impact (this is a slow query)
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; 
WITH XMLNAMESPACES   
(DEFAULT 'http://schemas.microsoft.com/sqlserver/2004/07/showplan')  
SELECT  TOP 50
	DB_NAME(eqp.dbid) AS DatabaseName,
	eqp.query_plan AS CompleteQueryPlan, 
	ecp.usecounts, 
	n.value('(@StatementSubTreeCost)[1]', 'NUMERIC(30,8)') AS StatementSubTreeCost, 
	n.value('(@StatementSubTreeCost)[1]', 'NUMERIC(30,8)') * ecp.usecounts AS Impact,
	n.value('(@StatementText)[1]', 'VARCHAR(4000)') AS StatementText, 
	n.value('(//QueryPlan/Warnings/PlanAffectingConvert[@ConvertIssue="Cardinality Estimate"]/@Expression)[1]', 'VARCHAR(4000)') AS Expression1, 
	n.value('(//QueryPlan/Warnings/PlanAffectingConvert[@ConvertIssue="Seek Plan"]/@Expression)[1]', 'VARCHAR(4000)') AS Expression2
FROM sys.dm_exec_cached_plans AS ecp 
CROSS APPLY sys.dm_exec_query_plan(ecp.plan_handle) AS eqp 
CROSS APPLY query_plan.nodes('/ShowPlanXML/BatchSequence/Batch/Statements/StmtSimple') AS qn(n) 
WHERE  n.query('.').exist('//Warnings/PlanAffectingConvert') = 1 
AND DB_NAME(eqp.dbid) IS NOT NULL
ORDER BY Impact DESC
