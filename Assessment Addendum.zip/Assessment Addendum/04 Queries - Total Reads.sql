-- Most Costly Queries by total Logical reads -- relates to memory pressure 
SELECT TOP 30
	total_logical_reads / qs.execution_count AS [AvgLogicalReads],
	total_logical_reads AS [TotalLogicalReads],
	qs.execution_count AS [Execution Count],
	[Individual Query] = REPLACE(
	SUBSTRING(qt.text,
		qs.statement_start_offset / 2,
		(CASE WHEN qs.statement_end_offset = -1
		THEN LEN(CONVERT(NVARCHAR(MAX), qt.text))
		* 2
		ELSE qs.statement_end_offset
		END - qs.statement_start_offset) / 2), '''', ''),
	[Parent Query] = qt.text,
	DatabaseName = DB_NAME(qt.dbid),
	qp.query_plan
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text(qs.[sql_handle]) AS qt
CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) AS qp
WHERE qt.dbid != 1
ORDER BY qs.total_logical_reads DESC;
