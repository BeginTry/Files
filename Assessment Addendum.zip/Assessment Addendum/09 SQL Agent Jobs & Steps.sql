/*
	List the "Ntirety" SQL Agent Jobs.
*/
--SELECT j.name JobName, j.description JobDescription, ss.name ScheduleName
--FROM msdb.dbo.sysjobs j
--LEFT JOIN msdb.dbo.sysjobschedules js
--	ON js.job_id = j.job_id 
--LEFT JOIN msdb.dbo.sysschedules ss
--	ON ss.schedule_id = js.schedule_id
--ORDER BY j.name

/*
	List the "Ntirety" SQL Agent Jobs, job steps, and associated schedule.
*/
SELECT j.name JobName, j.description JobDescription, s.step_id StepNumber, 
	s.step_name StepName, ss.name ScheduleName, s.command
FROM msdb.dbo.sysjobs j
JOIN msdb.dbo.sysjobsteps s
	ON s.job_id = j.job_id 
LEFT JOIN msdb.dbo.sysjobschedules js
	ON js.job_id = j.job_id 
LEFT JOIN msdb.dbo.sysschedules ss
	ON ss.schedule_id = js.schedule_id
ORDER BY j.name, s.step_id