IF EXISTS (
	SELECT *
	FROM tempdb.INFORMATION_SCHEMA.TABLES t
	WHERE t.TABLE_SCHEMA = 'guest'
	AND t.TABLE_NAME = 'IndexFragmentation'
)
BEGIN
	EXEC('DROP TABLE tempdb.guest.IndexFragmentation;');
END

--Create table in tempdb.
SELECT 
	DatabaseName = DB_NAME(),
	TableName = OBJECT_NAME(s.[object_id]),
	IndexName = i.name,
	[FragmentationPct] = ROUND(avg_fragmentation_in_percent, 2) ,
	[PageCount] = s.page_count
INTO tempdb.guest.IndexFragmentation
FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, NULL) s
INNER JOIN sys.indexes i
	ON s.[object_id] = i.[object_id]
	AND s.index_id = i.index_id
WHERE 1 = 2;


--Run once per database.
DECLARE @TSql NVARCHAR(MAX) = '';
DECLARE @DBName SYSNAME;
DECLARE curDB CURSOR FAST_FORWARD READ_ONLY FOR 
	SELECT name 
	FROM master.sys.databases d
	WHERE d.database_id > 4
	AND d.source_database_id IS NULL	--Exclude snapshots
	AND d.state_desc = 'ONLINE'
	AND d.name NOT IN ('');				--SSRS databases, etc.

OPEN curDB;
FETCH NEXT FROM curDB INTO @DBName;

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @TSql = '
	USE ' + QUOTENAME(@DBName) + ';

	--Run once per database.
	INSERT INTO tempdb.guest.IndexFragmentation
 	SELECT 
		DatabaseName = DB_NAME(),
		TableName = OBJECT_NAME(s.[object_id]),
		IndexName = i.name,
		[FragmentationPct] = ROUND(avg_fragmentation_in_percent, 2) ,
		[PageCount] = s.page_count
	FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, ''SAMPLED'') s
	JOIN sys.indexes i
		ON s.[object_id] = i.[object_id]
		AND s.index_id = i.index_id
	LEFT JOIN sys.dm_db_partition_stats ps 
		ON ps.object_id = i.object_id
		AND ps.index_id = i.index_id
		AND ps.used_page_count > 100
	WHERE i.name IS NOT NULL --NULL index name is a Heap.
	AND s.page_count > 100
	AND s.avg_fragmentation_in_percent > 0
	OPTION(MAXDOP 4)'
	EXEC (@Tsql);

	FETCH NEXT FROM curDB INTO @DBName;
END

CLOSE curDB;
DEALLOCATE curDB;


SELECT * FROM tempdb.guest.IndexFragmentation WHERE FragmentationPct > 0;
--	DROP TABLE tempdb.guest.IndexFragmentation;