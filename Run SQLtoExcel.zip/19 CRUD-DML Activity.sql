select case when CHARINDEX('SELECT',TEXT)>0 then 'SELECT' when CHARINDEX('INSERT',TEXT)>0 then 'INSERT' when CHARINDEX('DELETE',TEXT)>0 then 'DELETE'
when CHARINDEX('UPDATE',TEXT)>0 THEN 'UPDATE' else 'OTHER' end as StatementType,
SUM(execution_count) as UseCount, SUM(total_worker_time) as WorkerTime, SUM(total_physical_reads) as PhysicalReads, 
SUM(total_logical_reads) as LogicalReads, SUM(total_logical_writes) as LogicalWrites
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(QS.sql_handle) as ST
--CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle)
group by case when CHARINDEX('SELECT',TEXT)>0 then 'SELECT' when CHARINDEX('INSERT',TEXT)>0 then 'INSERT' when CHARINDEX('DELETE',TEXT)>0 then 'DELETE'
when CHARINDEX('UPDATE',TEXT)>0 THEN 'UPDATE' else 'OTHER' end