/*
	https://www.sqlshack.com/how-to-identify-and-monitor-unused-indexes-in-sql-server/
*/
IF EXISTS (
	SELECT *
	FROM tempdb.INFORMATION_SCHEMA.TABLES t
	WHERE t.TABLE_SCHEMA = 'guest'
	AND t.TABLE_NAME = 'DuplicateIndexes'
)
BEGIN
	EXEC('DROP TABLE tempdb.guest.DuplicateIndexes;');
END

CREATE TABLE tempdb.guest.DuplicateIndexes(
	DatabaseName SYSNAME,
	SchemaName SYSNAME,
	TableName SYSNAME,
	IndexName SYSNAME,
	ExactDuplicate SYSNAME,
	IndexSize_MB NUMERIC(20, 2)
)

/******************************************************/
--Run once per database.
DECLARE @TSql NVARCHAR(MAX) = '';
DECLARE @DBName SYSNAME;
DECLARE curDB CURSOR FAST_FORWARD READ_ONLY FOR 
	SELECT name 
	FROM master.sys.databases d
	WHERE d.database_id > 4
	AND d.source_database_id IS NULL	--Exclude snapshots
	AND d.state_desc = 'ONLINE'
	AND d.name NOT IN ('');				--SSRS databases, etc.

OPEN curDB;
FETCH NEXT FROM curDB INTO @DBName;

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @TSql = '
	USE ' + QUOTENAME(@DBName) + ';

;WITH indexcols AS
(
	SELECT object_id AS id, index_id AS indid, name,
	(SELECT CASE keyno WHEN 0 THEN NULL ELSE colid END AS [data()]
	FROM sys.sysindexkeys as k
	WHERE k.id = i.object_id
	AND k.indid = i.index_id
	ORDER BY keyno, colid
	FOR XML PATH('''')) as cols,
	(SELECT CASE keyno WHEN 0 THEN colid ELSE NULL END AS [data()]
	FROM sys.sysindexkeys as k
	WHERE k.id = i.object_id
	AND k.indid = i.index_id
	ORDER BY colid
	FOR XML PATH('''')) AS inc
	FROM sys.indexes AS i
)
INSERT INTO tempdb.guest.DuplicateIndexes
SELECT
	DB_NAME() AS DatabaseName,
	OBJECT_SCHEMA_NAME(c1.id) AS SchemaName,
	OBJECT_NAME(c1.id) AS TableName,
	c1.name AS [Index],
	c2.name AS ExactDuplicate,
	ps.used_page_count * 8.0 / 1024.0 AS IndexSize_MB
FROM indexcols AS c1
JOIN indexcols AS c2
	ON c1.id = c2.id
	AND c1.indid < c2.indid
	AND c1.cols = c2.cols
	AND c1.inc = c2.inc
JOIN sys.dm_db_partition_stats ps
	ON ps.[object_id] = c1.id 
	AND ps.index_id = c1.indid;'
	EXEC (@Tsql);

	FETCH NEXT FROM curDB INTO @DBName;
END

CLOSE curDB;
DEALLOCATE curDB;


/*
	SELECT i.sqlserver_start_time
	FROM master.sys.dm_os_sys_info i
*/
SELECT *
FROM tempdb.guest.DuplicateIndexes u
WHERE u.IndexName IS NOT NULL
ORDER BY u.DatabaseName, u.SchemaName, u.TableName


