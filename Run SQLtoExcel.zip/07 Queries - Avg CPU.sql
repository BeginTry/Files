IF EXISTS (
	SELECT *
	FROM tempdb.INFORMATION_SCHEMA.TABLES t
	WHERE t.TABLE_SCHEMA = 'guest'
	AND t.TABLE_NAME = 'AverageCPU'
)
BEGIN
	EXEC('DROP TABLE tempdb.guest.AverageCPU;');
END

--	Most Costly Queries by Avg CPU usage
;WITH CPUQ AS
(	
	SELECT TOP 30
		AverageCPU = total_worker_time / qs.execution_count,
		TotalCPU = total_worker_time,
		ExecutionCount = qs.execution_count,
 
		IndividualQuery = REPLACE(
			SUBSTRING(qt.text,
				qs.statement_start_offset / 2,
				(CASE WHEN qs.statement_end_offset = -1
				THEN LEN(CONVERT(NVARCHAR(MAX), qt.text))
				* 2
				ELSE qs.statement_end_offset
				END - qs.statement_start_offset) / 2), '''', ''),

		ParentQuery = qt.text,
		DatabaseName = DB_NAME(qt.dbid),
		qs.plan_handle
	FROM sys.dm_exec_query_stats qs
	CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS qt
	WHERE qt.dbid != 1
	ORDER BY AverageCPU DESC
)
SELECT CPUQ.*, qp.query_plan
INTO tempdb.guest.AverageCPU
FROM  CPUQ
CROSS APPLY sys.dm_exec_query_plan(CPUQ.plan_handle) AS qp

SELECT 
	c.AverageCPU,
	c.TotalCPU,
	c.ExecutionCount,
	c.IndividualQuery,
	c.ParentQuery,
	c.DatabaseName
FROM tempdb.guest.AverageCPU c
ORDER BY c.AverageCPU DESC;
