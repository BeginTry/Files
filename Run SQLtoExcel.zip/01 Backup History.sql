SELECT 
	CONVERT(CHAR(100), SERVERPROPERTY('Servername')) AS Server, 
	bs.database_name, 
	bs.backup_start_date, 
	bs.backup_finish_date, 
	bs.expiration_date, 
	CASE bs.type 
		WHEN 'D' THEN 'Database' 
		WHEN 'I' THEN 'Differential'
		WHEN 'L' THEN 'Log' 
	END AS backup_type, 
	bs.backup_size, 
	bs.compressed_backup_size,
	bmf.logical_device_name, 
	bmf.physical_device_name, 
	bs.name AS backupset_name, 
	bs.description 
FROM msdb.dbo.backupmediafamily bmf
INNER JOIN msdb.dbo.backupset bs
	ON bmf.media_set_id = bs.media_set_id 
WHERE (CONVERT(datetime, bs.backup_start_date, 102) >= GETDATE() - 15) 
ORDER BY 
	bs.database_name, 
	bs.backup_finish_date;

