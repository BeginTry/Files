SELECT TOP(30)
	DB_NAME(qp.dbid) DBName,
	qp.query_plan,
	OBJECT_NAME(s.object_id) ProcName, 
	--s.sql_handle,
	--s.plan_handle,
	s.last_execution_time,
	s.execution_count,
	s.total_worker_time,
	s.total_logical_reads,
	s.total_logical_writes,
	s.total_logical_reads / s.execution_count average_logical_reads,
	s.total_logical_writes / s.execution_count average_logical_writes,
	s.total_elapsed_time / s.execution_count average_elapsed_time,
	s.total_worker_time / s.execution_count average_worker_time
FROM sys.dm_exec_procedure_stats s
CROSS APPLY sys.dm_exec_query_plan(s.plan_handle) qp
--WHERE s.database_id = DB_ID('TIS')
ORDER BY s.total_logical_reads DESC