IF EXISTS (
	SELECT *
	FROM tempdb.INFORMATION_SCHEMA.TABLES t
	WHERE t.TABLE_SCHEMA = 'guest'
	AND t.TABLE_NAME = 'TotalReads'
)
BEGIN
	EXEC('DROP TABLE tempdb.guest.TotalReads;');
END

-- Most Costly Queries by total Logical reads -- relates to memory pressure 
SELECT TOP 30
	total_logical_reads / qs.execution_count AS AvgLogicalReads,
	total_logical_reads AS TotalLogicalReads,
	qs.execution_count AS ExecutionCount,
	REPLACE(
		SUBSTRING(qt.text,
			qs.statement_start_offset / 2,
			(CASE WHEN qs.statement_end_offset = -1
			THEN LEN(CONVERT(NVARCHAR(MAX), qt.text))
			* 2
			ELSE qs.statement_end_offset
			END - qs.statement_start_offset) / 2), '''', '') AS IndividualQuery,
		qt.text AS ParentQuery,
	DB_NAME(qt.dbid) AS DatabaseName,
	qp.query_plan
INTO tempdb.guest.TotalReads
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text(qs.[sql_handle]) AS qt
CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) AS qp
WHERE qt.dbid != 1
ORDER BY qs.total_logical_reads DESC;

SELECT r.AvgLogicalReads,
	r.TotalLogicalReads,
	r.ExecutionCount,
	r.IndividualQuery,
	r.ParentQuery,
	r.DatabaseName
FROM tempdb.guest.TotalReads r
ORDER BY r.TotalLogicalReads DESC;