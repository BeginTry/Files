/*
	sp_configure 'show advanced options', 1 ;  
	GO  
	RECONFIGURE ;  
	GO  
	sp_configure 'blocked process threshold', 3 ;  
	GO  
	RECONFIGURE ;  
	GO  
*/

;WITH XEvents AS
(
	SELECT object_name, CAST(event_data AS XML) AS event_data
	FROM sys.fn_xe_file_target_read_file ( 'Ntirety-Blocking*.xel', NULL, NULL, NULL )  
)
SELECT object_name,

		--blocked_process_report
		--event_data.value ('(/event/data[@name=''database_id'']/value)[1]', 'BIGINT') AS database_id,
		event_data.value ('(/event/data[@name=''database_name'']/value)[1]', 'VARCHAR(128)') AS database_name,
		event_data.value ('(/event/data[@name=''blocked_process'']/value/blocked-process-report/blocked-process)[1]', 'VARCHAR(MAX)') AS blocked_process,
		event_data.value ('(/event/data[@name=''blocked_process'']/value/blocked-process-report/blocking-process)[1]', 'VARCHAR(MAX)') AS blocking_process,
		event_data.value ('(/event/data[@name=''object_id'']/value)[1]', 'BIGINT') AS object_id,
		event_data.value ('(/event/data[@name=''index_id'']/value)[1]', 'BIGINT') AS index_id,
		event_data.value ('(/event/data[@name=''lock_mode'']/text)[1]', 'VARCHAR(8)') AS lock_mode,
		event_data.value ('(/event/action[@name=''server_principal_name'']/value)[1]', 'VARCHAR(128)') AS server_principal_name,
		event_data.value ('(/event/@timestamp)[1]', 'DATETIME') AS [Time],
        event_data.value ('(/event/data[@name=''duration'']/value)[1]', 'BIGINT') AS Duration,
		event_data.value ('(/event/action[@name=''session_id'']/value)[1]', 'BIGINT') AS session_id,

		CASE
			WHEN object_name = 'xml_deadlock_report' THEN event_data
			ELSE CAST(NULL AS XML)
		END AS xml_deadlock_report
FROM XEvents 