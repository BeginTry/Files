;WITH XEvents AS
(
	SELECT object_name, CAST(event_data AS XML) AS event_data
	FROM sys.fn_xe_file_target_read_file ( 'Deadlock Monitor*.xel', NULL, NULL, NULL )  
)
SELECT object_name,
		--rpc_completed
		--sp_statement_completed
		--sql_batch_completed
		--sql_statement_completed
		event_data.value ('(/event/@timestamp)[1]', 'DATETIME') AS [Time],
        event_data.value ('(/event/action[@name=''database_name'']/value)[1]', 'VARCHAR(128)') AS database_name,
		event_data.value ('(/event/action[@name=''object_name'']/value)[1]', 'VARCHAR(128)') AS object_name,
        event_data.value ('(/event/data[@name=''duration'']/value)[1]', 'BIGINT') AS Duration,
		event_data.value ('(/event/data[@name=''physical_reads'']/value)[1]', 'BIGINT') AS physical_reads,
		event_data.value ('(/event/data[@name=''logical_reads'']/value)[1]', 'BIGINT') AS logical_reads,
		event_data.value ('(/event/data[@name=''writes'']/value)[1]', 'BIGINT') AS writes,
		event_data.value ('(/event/data[@name=''statement'']/value)[1]', 'VARCHAR(MAX)') AS statement,
		event_data.value ('(/event/action[@name=''sql_text'']/value)[1]', 'VARCHAR(MAX)') AS sql_text,
		event_data.value ('(/event/action[@name=''session_id'']/value)[1]', 'BIGINT') AS session_id
FROM XEvents 